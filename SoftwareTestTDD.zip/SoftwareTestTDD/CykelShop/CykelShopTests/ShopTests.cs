﻿using NUnit.Framework;
using CykelShop;
using System;
using System.Collections.Generic;
using System.Text;

namespace CykelShop.Tests
{
    [TestFixture()]
    public class ShopTests
    {
        [Test()]
        public void MainTest()
        {
            Assert.That(Shop.testStart, Is.EqualTo("Sum text"));
        }

        [Test()]
        public void CheckIfBikesGotCreated()
        {
            Shop.bikes.Clear();
            Shop.Create();

            Assert.That(Shop.bikes[0].name, Is.EqualTo("Turbo"));
            Assert.That(Shop.bikes[8].name, Is.EqualTo("Stunter"));
        }

        [Test()]
        public void CheckIfBikesCanBeRead()
        {
            Shop.bikes.Clear();
            Shop.Create();
            Shop.Read();

            Assert.That(Shop.bikes[4].name, Is.EqualTo("Rock Climber"));
        }

        [Test()]
        public void CheckIfBikesGotUpdated()
        {
            Shop.bikes.Clear();
            Shop.Create();
            Shop.Update();

            Bike updatedBikeValue = new Bike("3-Wheelz","Three Wheeled Bike", 250);
            //Bike oldBikeValue = new Bike("Off-Roader","Mountain Bike", 350);

            Assert.That(Shop.bikes[5].name, Is.EqualTo(updatedBikeValue.name));
            //Assert.That(Shop.bikes[5], Is.EqualTo(oldBikeValue));
        }

        [Test()]
        public void CheckIfBikesGotDeleted()
        {
            Shop.bikes.Clear();
            Shop.Create();
            Shop.Delete();

            Assert.That(Shop.bikes[Shop.deleteBike].name, Is.EqualTo("Trickster"));
        }
    }
}