﻿using System;

namespace CykelShop
{
    public class Bike
    {
        public string name;
        public string type;
        public int price;

        public Bike(string name, string type, int price)
        {
            this.name = name;
            this.type = type;
            this.price = price;
        }
    }
}
