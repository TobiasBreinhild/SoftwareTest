﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CykelShop
{
    public class Shop
    {
        public static List<Bike> bikes = new List<Bike>();

        public static string testStart = "Sum text";

        public static int readableBike = 4;

        public static int editBike = 5;

        public static int deleteBike = 6;

        public static void Main()
        {
            Create();
            Read();
            Update();
            Delete();
        }

        public static void Create()
        {
            bikes.Add(new Bike("Turbo", "Race Bike", 200));
            bikes.Add(new Bike("Accelerator", "Race Bike", 300));
            bikes.Add(new Bike("Nitro", "Race Bike", 450));
            bikes.Add(new Bike("Mountaineer", "Mountain Bike", 500));
            bikes.Add(new Bike("Rock Climber", "Mountain Bike", 200));
            bikes.Add(new Bike("Off-Roader", "Mountain Bike", 350));
            bikes.Add(new Bike("Skater", "BMX Bike", 450));
            bikes.Add(new Bike("Trickster", "BMX Bike", 150));
            bikes.Add(new Bike("Stunter", "BMX Bike", 200));
            bikes.Add(new Bike("Show-Off", "Richmans Bike", 2500000));
        }

        public static void Read()
        {
            Console.WriteLine("Bike name: " + bikes[readableBike].name + " | Bike type: " + bikes[readableBike].type +" | Price: "+ bikes[readableBike].price);
        }

        public static void Update()
        {
            bikes[editBike] = new Bike("3-Wheelz", "Three Wheeled Bike", 250);
        }

        public static void Delete()
        {
            bikes.RemoveAt(deleteBike);
        }
    }
}
